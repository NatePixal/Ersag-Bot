'use strict';

window.ErsagMiniApp = {
  apiBase: '/api',

  async getLeaderConfig(userId) {
    const url = new URL(`${this.apiBase}/leader-config`, window.location.origin);
    if (userId) url.searchParams.set('user_id', userId);
    const res = await fetch(url.toString(), { headers: { 'Accept': 'application/json' } });
    if (!res.ok) throw new Error(`leader-config failed: ${res.status}`);
    return res.json();
  },

  async applyLeaderConfig(userId) {
    const cfg = await this.getLeaderConfig(userId);
    window.currentLeaderConfig = cfg;

    const sponsorEl = document.getElementById('step2-sponsor-id');
    if (sponsorEl && cfg.sponsor_id) sponsorEl.textContent = cfg.sponsor_id;

    const regLinkEls = document.querySelectorAll('[data-reg-link]');
    regLinkEls.forEach((el) => {
      el.setAttribute('href', cfg.registration_link || '#');
    });

    return cfg;
  },
};
