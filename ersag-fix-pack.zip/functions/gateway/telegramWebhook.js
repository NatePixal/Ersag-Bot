'use strict';

const { admin, db } = require('../config/db');
const env = require('../config/env');
const { sendMessage, answerCallbackQuery, answerPreCheckoutQuery, approveChatJoinRequest } = require('../utils/telegramApi');
const { cleanLeaderCode, buildRegistrationLink, upsertUserFromStart, getLeaderConfigByUserId } = require('../services/leaderService');
const { findProductByCode, searchCatalog } = require('../services/catalogService');
const { generateResponse } = require('../services/aiService');

function getBotToken(botName) {
  const key = String(botName || '').toLowerCase();
  if (key === 'master') return env.MASTER_BOT_TOKEN;
  if (key === 'leader') return env.LEADER_BOT_TOKEN;
  if (key === 'sales') return env.SALES_BOT_TOKEN;
  if (key === 'billing') return env.BILLING_BOT_TOKEN;
  return '';
}

function isAuthorizedWebhook(req) {
  const received = req.get('x-telegram-bot-api-secret-token') || '';
  return received === env.WEBHOOK_SECRET;
}

function buildKeyboard({ webAppUrl, registrationLink, adminPanelUrl }) {
  const row1 = [];
  if (webAppUrl) row1.push({ text: '🛍 Katalog', web_app: { url: webAppUrl } });
  if (registrationLink) row1.push({ text: '✅ Ro\'yxatdan o\'tish', url: registrationLink });

  const keyboard = [row1];
  keyboard.push([{ text: '👨‍⚕️ Doctor Ersag', callback_data: 'doctor_help' }]);
  keyboard.push([{ text: '📘 Biznes Maktabi', callback_data: 'open_lessons' }]);
  if (adminPanelUrl) keyboard.push([{ text: '🛠 Admin Panel', url: adminPanelUrl }]);

  return { reply_markup: { inline_keyboard: keyboard.filter((r) => r.length > 0) } };
}

async function recordPayment({ telegramId, payload, providerPaymentChargeId, totalAmount, currency }) {
  const ref = db.collection('payments').doc(`${telegramId}_${Date.now()}`);
  await ref.set({
    telegram_id: String(telegramId),
    payload: payload || '',
    provider_payment_charge_id: providerPaymentChargeId || '',
    total_amount: totalAmount || 0,
    currency: currency || '',
    created_at: admin.firestore.Timestamp.now(),
  });
  return ref;
}

async function handleSuccessfulPayment(botToken, message) {
  const payment = message.successful_payment;
  const telegramId = message.from.id.toString();
  await recordPayment({
    telegramId,
    payload: payment.invoice_payload,
    providerPaymentChargeId: payment.provider_payment_charge_id,
    totalAmount: payment.total_amount,
    currency: payment.currency,
  });

  if (String(payment.invoice_payload || '').startsWith('leader-subscription:')) {
    const leaderCode = cleanLeaderCode(payment.invoice_payload.split(':')[1]);
    const leaderRef = db.collection('leaders').doc(String(leaderCode));
    const now = new Date();
    const expiry = new Date(now);
    expiry.setDate(expiry.getDate() + 30);

    await leaderRef.set({
      leader_code: leaderCode,
      subscription_active: true,
      subscription_paid_at: admin.firestore.Timestamp.fromDate(now),
      subscription_expires_at: admin.firestore.Timestamp.fromDate(expiry),
    }, { merge: true });

    await sendMessage(botToken, telegramId, '✅ Toʻlov qabul qilindi. Obuna faollashtirildi.');
    return;
  }

  await db.collection('users').doc(String(telegramId)).set({
    is_paid: true,
    paid_at: admin.firestore.Timestamp.now(),
  }, { merge: true });

  await sendMessage(botToken, telegramId, '✅ Toʻlov qabul qilindi. Kirish ochildi.');
}

async function handlePreCheckout(botToken, update) {
  const q = update.pre_checkout_query;
  if (!q) return;
  await answerPreCheckoutQuery(botToken, { pre_checkout_query_id: q.id, ok: true });
}

async function handleCallback(botToken, update, chatId) {
  const cb = update.callback_query;
  if (!cb) return;

  await answerCallbackQuery(botToken, { callback_query_id: cb.id });

  const data = String(cb.data || '');
  if (data === 'doctor_help') {
    await sendMessage(botToken, chatId, '👨‍⚕️ Savolingizni yozing. Men mahsulot bo‘yicha yordam beraman.');
    return;
  }
  if (data === 'open_lessons') {
    await sendMessage(botToken, chatId, '📘 Biznes Maktabi mini-app ichida ochiladi.');
    return;
  }
}

async function handleTextMessage(botName, botToken, message) {
  const telegramId = message.from.id.toString();
  const firstName = message.from.first_name || 'User';
  const username = message.from.username || '';
  const text = String(message.text || '').trim();
  const lang = message.from.language_code === 'ru' ? 'ru' : 'uz';

  const defaultLeaderCode = env.DEFAULT_LEADER_CODE;
  const webAppUrl = `${env.WEBAPP_URL.replace(/\/$/, '')}/index.html?user_id=${telegramId}`;
  const adminPanelUrl = `${env.WEBAPP_URL.replace(/\/$/, '')}/admin.html`;

  let userData = null;
  const startMatch = text.match(/^\/start(?:\s+(.+))?$/i);
  if (startMatch) {
    const rawParam = String(startMatch[1] || '').trim();
    const leaderCode = cleanLeaderCode(rawParam) || defaultLeaderCode;

    userData = await upsertUserFromStart({
      telegramId,
      firstName,
      username,
      leaderCode,
    });

    const leaderConfig = await getLeaderConfigByUserId(telegramId);
    const keyboard = buildKeyboard({
      webAppUrl,
      registrationLink: leaderConfig.registration_link,
      adminPanelUrl: String(telegramId) === String(env.ADMIN_TELEGRAM_ID) ? adminPanelUrl : '',
    });

    const welcome = lang === 'ru'
      ? `Привет, ${firstName}!\n\nВаш спонсор: ${leaderConfig.sponsor_id}`
      : `Salom, ${firstName}!\n\nSizning sponsoringiz: ${leaderConfig.sponsor_id}`;

    await sendMessage(botToken, telegramId, welcome, keyboard);
    return;
  }

  if (text === '/admin' && String(telegramId) === String(env.ADMIN_TELEGRAM_ID)) {
    await sendMessage(botToken, telegramId, '🛠 Admin control center\n\n/api/health\n/admin.html', {
      reply_markup: {
        inline_keyboard: [[{ text: 'Open Admin Panel', url: adminPanelUrl }]],
      },
    });
    return;
  }

  userData = userData || (await (async () => {
    const ref = db.collection('users').doc(String(telegramId));
    const snap = await ref.get();
    return snap.exists ? snap.data() : null;
  })());

  const leaderCode = cleanLeaderCode(userData?.leader_code) || defaultLeaderCode;
  const leaderConfig = await getLeaderConfigByUserId(telegramId);
  const keyboard = buildKeyboard({
    webAppUrl,
    registrationLink: leaderConfig.registration_link || buildRegistrationLink(leaderCode),
    adminPanelUrl: String(telegramId) === String(env.ADMIN_TELEGRAM_ID) ? adminPanelUrl : '',
  });

  const product = await findProductByCode(text);
  if (product) {
    const name = lang === 'ru' ? (product.name_ru || product.name_uz || product.name || product.code) : (product.name_uz || product.name_ru || product.name || product.code);
    const desc = lang === 'ru' ? (product.desc_ru || product.desc_uz || '') : (product.desc_uz || product.desc_ru || '');
    const usage = lang === 'ru' ? (product.usage_ru || product.usage_uz || '') : (product.usage_uz || product.usage_ru || '');

    await sendMessage(
      botToken,
      telegramId,
      `${name}\n\n${desc}${usage ? `\n\n${usage}` : ''}`,
      keyboard
    );
    return;
  }

  if (/^\/doctor/i.test(text) || /^doctor/i.test(text)) {
    await sendMessage(botToken, telegramId, lang === 'ru'
      ? 'Опишите, что вас беспокоит, и я предложу подходящие товары из базы.'
      : 'Muammoingizni yozing, men bazadan mos mahsulotlarni ko‘rsataman.',
      keyboard
    );
    return;
  }

  const productMatches = await searchCatalog(text);
  const context = productMatches.slice(0, 5).map((p) => `${p.code || ''} ${p.name_uz || p.name || ''}`).join(' | ');

  let reply;
  try {
    reply = await generateResponse({ text, lang, catalogContext: context });
  } catch (err) {
    console.error('AI failure:', err.message);
    reply = lang === 'ru'
      ? '⚠️ Временная ошибка AI. Попробуйте снова.'
      : '⚠️ AI vaqtincha ishlamayapti. Qayta urinib ko‘ring.';
  }

  await sendMessage(botToken, telegramId, reply, keyboard).catch((err) => {
    console.error('sendMessage failed:', err.message);
  });
}

async function telegramWebhook(req, res) {
  try {
    if (!isAuthorizedWebhook(req)) {
      console.warn('Invalid webhook secret');
      return res.status(401).send('unauthorized');
    }

    const botName = String(req.params.bot || '').toLowerCase();
    const botToken = getBotToken(botName);
    if (!botToken) {
      console.warn(`Unknown bot route: ${botName}`);
      return res.sendStatus(200);
    }

    const update = req.body || {};

    if (update.pre_checkout_query) {
      await handlePreCheckout(botToken, update);
      return res.sendStatus(200);
    }

    if (update.message?.successful_payment) {
      await handleSuccessfulPayment(botToken, update.message);
      return res.sendStatus(200);
    }

    if (update.callback_query) {
      const chatId = update.callback_query.message?.chat?.id;
      await handleCallback(botToken, update, chatId);
      return res.sendStatus(200);
    }

    if (update.chat_join_request) {
      const reqUpdate = update.chat_join_request;
      if (String(reqUpdate.from?.id || '') === String(env.ADMIN_TELEGRAM_ID)) {
        await approveChatJoinRequest(botToken, {
          chat_id: reqUpdate.chat.id,
          user_id: reqUpdate.from.id,
        });
      }
      return res.sendStatus(200);
    }

    if (update.message) {
      await handleTextMessage(botName, botToken, update.message);
      return res.sendStatus(200);
    }

    return res.sendStatus(200);
  } catch (error) {
    console.error('telegramWebhook error:', error);
    return res.sendStatus(200);
  }
}

module.exports = { telegramWebhook };
