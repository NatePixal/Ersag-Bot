'use strict';

const express = require('express');
const { db } = require('../config/db');
const env = require('../config/env');
const { getLeaderConfigByUserId } = require('../services/leaderService');
const { getCatalogRows, findProductByCode } = require('../services/catalogService');

const router = express.Router();

router.get('/health', (_, res) => {
  res.json({ ok: true, service: 'miniapp-api' });
});

router.get('/leader-config', async (req, res) => {
  try {
    const userId = String(req.query.user_id || '').trim();
    const leaderConfig = userId
      ? await getLeaderConfigByUserId(userId)
      : {
          user_id: '',
          leader_code: env.DEFAULT_LEADER_CODE,
          sponsor_id: env.DEFAULT_LEADER_CODE,
          registration_link: env.PUBLIC_REG_URL,
          vip_link: '',
          admin_group_id: env.ADMIN_GROUP_ID || '',
          is_active: true,
          subscription_active: true,
        };

    res.json(leaderConfig);
  } catch (error) {
    console.error('leader-config failed:', error);
    res.status(500).json({ error: 'leader-config_failed' });
  }
});

router.get('/catalog', async (req, res) => {
  try {
    const rows = await getCatalogRows();
    const category = String(req.query.category || '').trim().toLowerCase();
    const q = String(req.query.q || '').trim().toLowerCase();

    let filtered = rows;
    if (category) {
      filtered = filtered.filter((item) => String(item.category || '').trim().toLowerCase() === category);
    }
    if (q) {
      filtered = filtered.filter((item) => JSON.stringify(item).toLowerCase().includes(q));
    }

    res.json({ count: filtered.length, rows: filtered });
  } catch (error) {
    console.error('catalog failed:', error);
    res.status(500).json({ error: 'catalog_failed' });
  }
});

router.get('/product/:code', async (req, res) => {
  try {
    const product = await findProductByCode(req.params.code);
    if (!product) return res.status(404).json({ error: 'not_found' });
    res.json(product);
  } catch (error) {
    console.error('product lookup failed:', error);
    res.status(500).json({ error: 'product_lookup_failed' });
  }
});

router.get('/user/:id', async (req, res) => {
  try {
    const snap = await db.collection('users').doc(String(req.params.id)).get();
    if (!snap.exists) return res.status(404).json({ error: 'not_found' });
    res.json({ id: req.params.id, ...snap.data() });
  } catch (error) {
    console.error('user lookup failed:', error);
    res.status(500).json({ error: 'user_lookup_failed' });
  }
});

module.exports = router;
