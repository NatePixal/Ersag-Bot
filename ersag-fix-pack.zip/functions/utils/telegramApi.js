'use strict';

const axios = require('axios');

async function tgRequest(token, method, payload) {
  if (!token) throw new Error(`Missing Telegram token for ${method}`);
  const url = `https://api.telegram.org/bot${token}/${method}`;
  const { data } = await axios.post(url, payload, { timeout: 15000 });
  return data;
}

async function sendMessage(token, chat_id, text, extra = {}) {
  return tgRequest(token, 'sendMessage', { chat_id, text, ...extra });
}

async function editMessageText(token, payload) {
  return tgRequest(token, 'editMessageText', payload);
}

async function answerCallbackQuery(token, payload) {
  return tgRequest(token, 'answerCallbackQuery', payload);
}

async function answerPreCheckoutQuery(token, payload) {
  return tgRequest(token, 'answerPreCheckoutQuery', payload);
}

async function approveChatJoinRequest(token, payload) {
  return tgRequest(token, 'approveChatJoinRequest', payload);
}

module.exports = {
  tgRequest,
  sendMessage,
  editMessageText,
  answerCallbackQuery,
  answerPreCheckoutQuery,
  approveChatJoinRequest,
};
