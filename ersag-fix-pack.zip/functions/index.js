'use strict';

const { onRequest } = require('firebase-functions/v2/https');
const express = require('express');
const cors = require('cors');
const { telegramWebhook } = require('./gateway/telegramWebhook');
const miniAppRoutes = require('./miniapp/api');
const env = require('./config/env');

process.on('unhandledRejection', (err) => console.error('unhandledRejection:', err));
process.on('uncaughtException', (err) => console.error('uncaughtException:', err));

const secretList = [
  'MASTER_BOT_TOKEN',
  'LEADER_BOT_TOKEN',
  'SALES_BOT_TOKEN',
  'BILLING_BOT_TOKEN',
  'GROQ_API_KEY',
  'ADMIN_TELEGRAM_ID',
  'WEBHOOK_SECRET',
];

const botApp = express();
botApp.use(express.json());
botApp.use(cors({ origin: true }));
botApp.post('/webhook/:bot', telegramWebhook);

const apiApp = express();
apiApp.use(cors({ origin: true }));
apiApp.use(express.json());
apiApp.use('/api', miniAppRoutes);
apiApp.get('/health', (_, res) => res.json({ ok: true, service: 'api' }));

exports.botGateway = onRequest(
  {
    region: 'us-central1',
    secrets: secretList,
    timeoutSeconds: 60,
    memory: '256MiB',
    maxInstances: 20,
  },
  botApp
);

exports.api = onRequest(
  {
    region: 'us-central1',
    secrets: secretList,
    timeoutSeconds: 60,
    memory: '256MiB',
    maxInstances: 20,
  },
  apiApp
);

exports.health = onRequest({ region: 'us-central1' }, (_, res) => {
  res.json({ ok: true, ready: true, defaultLeader: env.DEFAULT_LEADER_CODE });
});
