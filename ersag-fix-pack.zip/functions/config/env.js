'use strict';

function readEnv(name, fallback = '') {
  const value = process.env[name];
  if (value === undefined || value === null || value === '') {
    if (fallback === '') {
      console.warn(`⚠️ Missing env: ${name}`);
    }
    return fallback;
  }
  return value;
}

function mustEnv(name) {
  const value = process.env[name];
  if (value === undefined || value === null || value === '') {
    throw new Error(`Missing required env: ${name}`);
  }
  return value;
}

module.exports = {
  // Telegram bot tokens
  get MASTER_BOT_TOKEN() { return mustEnv('MASTER_BOT_TOKEN'); },
  get LEADER_BOT_TOKEN() { return mustEnv('LEADER_BOT_TOKEN'); },
  get SALES_BOT_TOKEN() { return mustEnv('SALES_BOT_TOKEN'); },
  get BILLING_BOT_TOKEN() { return mustEnv('BILLING_BOT_TOKEN'); },

  // AI
  get GROQ_API_KEY() { return mustEnv('GROQ_API_KEY'); },
  get GROQ_MODEL() { return readEnv('GROQ_MODEL', 'llama-3.3-70b-versatile'); },

  // Telegram / admin
  get ADMIN_TELEGRAM_ID() { return mustEnv('ADMIN_TELEGRAM_ID'); },
  get WEBHOOK_SECRET() { return mustEnv('WEBHOOK_SECRET'); },
  get ADMIN_GROUP_ID() { return readEnv('ADMIN_GROUP_ID', ''); },

  // App config
  get WEBAPP_URL() { return readEnv('WEBAPP_URL', 'https://YOUR-PROJECT.web.app'); },
  get DEFAULT_LEADER_CODE() { return readEnv('DEFAULT_LEADER_CODE', '5422685'); },
  get PUBLIC_REG_URL() {
    return readEnv(
      'PUBLIC_REG_URL',
      'https://www.ersagglobal.uz/account.asp?mod=myaccount&sub=edit&action=register&p=1&red=&sponsor=5422685'
    );
  },
  get GOOGLE_SHEETS_ID() { return readEnv('GOOGLE_SHEETS_ID', '13vVUizWwWowU3Q26v7G_20fk3Iott9TTIWdcE_93U6s'); },

  validateCore() {
    const required = ['MASTER_BOT_TOKEN', 'LEADER_BOT_TOKEN', 'SALES_BOT_TOKEN', 'BILLING_BOT_TOKEN', 'GROQ_API_KEY', 'ADMIN_TELEGRAM_ID', 'WEBHOOK_SECRET'];
    required.forEach(mustEnv);
    return true;
  },
};
