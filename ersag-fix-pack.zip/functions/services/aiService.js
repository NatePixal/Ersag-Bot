'use strict';

const { OpenAI } = require('openai');
const env = require('../config/env');

let client = null;

function getClient() {
  if (client) return client;
  if (!env.GROQ_API_KEY) return null;
  client = new OpenAI({
    apiKey: env.GROQ_API_KEY,
    baseURL: 'https://api.groq.com/openai/v1',
  });
  return client;
}

async function generateResponse({ text, lang = 'uz', catalogContext = '', doctorContext = '' }) {
  const c = getClient();
  if (!c) {
    return lang === 'ru'
      ? '⚠️ AI временно недоступен. Можете открыть каталог ниже.'
      : '⚠️ AI vaqtincha ishlamayapti. Katalogni pastdan ochishingiz mumkin.';
  }

  const system = [
    'You are Ersag assistant.',
    'Give concise, helpful product guidance.',
    'Do not claim to diagnose medical conditions.',
    'If the issue is sensitive, advise human consultant follow-up.',
    lang === 'ru' ? 'Reply in Russian.' : 'Reply in Uzbek.',
    catalogContext ? `Catalog context: ${catalogContext}` : '',
    doctorContext ? `Doctor knowledge: ${doctorContext}` : '',
  ].filter(Boolean).join('\n');

  const response = await c.chat.completions.create({
    model: env.GROQ_MODEL,
    temperature: 0.2,
    messages: [
      { role: 'system', content: system },
      { role: 'user', content: text },
    ],
  });

  return response?.choices?.[0]?.message?.content?.trim() || (lang === 'ru'
    ? '⚠️ Не удалось сформировать ответ.'
    : '⚠️ Javob shakllantirilmadi.');
}

module.exports = { generateResponse };
