'use strict';

const { db } = require('../config/db');

function normalize(value) {
  return String(value || '').trim().toLowerCase().replace(/\s+/g, ' ');
}

async function getCatalogRows() {
  const sysDoc = await db.collection('sys_data').doc('catalog').get();
  if (sysDoc.exists) {
    const data = sysDoc.data() || {};
    if (Array.isArray(data.rows) && data.rows.length) return data.rows;
  }

  const colSnap = await db.collection('catalog').get();
  const rows = [];
  colSnap.forEach((doc) => rows.push({ id: doc.id, ...doc.data() }));
  return rows;
}

async function findProductByCode(code) {
  const target = normalize(code);
  if (!target) return null;

  const rows = await getCatalogRows();
  return rows.find((item) => normalize(item.code) === target) || null;
}

async function searchCatalog(query) {
  const q = normalize(query);
  if (!q) return [];
  const rows = await getCatalogRows();
  return rows.filter((item) => {
    const hay = [item.name_uz, item.name_ru, item.desc_uz, item.desc_ru, item.code, item.category]
      .map(normalize)
      .join(' ');
    return hay.includes(q);
  });
}

module.exports = {
  getCatalogRows,
  findProductByCode,
  searchCatalog,
};
