'use strict';

const { admin, db } = require('../config/db');
const env = require('../config/env');

function cleanLeaderCode(value) {
  if (!value) return '';
  const raw = String(value).trim();
  const digits = raw.replace(/[^0-9]/g, '');
  return digits || raw;
}

function buildRegistrationLink(sponsorId) {
  return `https://www.ersagglobal.uz/account.asp?mod=myaccount&sub=edit&action=register&p=1&red=&sponsor=${encodeURIComponent(sponsorId)}`;
}

async function getUser(telegramId) {
  const ref = db.collection('users').doc(String(telegramId));
  const snap = await ref.get();
  return snap.exists ? { ref, data: snap.data() } : { ref, data: null };
}

async function upsertUserFromStart({ telegramId, firstName, username, leaderCode }) {
  const ref = db.collection('users').doc(String(telegramId));
  const now = admin.firestore.Timestamp.now();
  const payload = {
    telegram_id: String(telegramId),
    first_name: firstName || '',
    username: username || '',
    leader_code: cleanLeaderCode(leaderCode) || env.DEFAULT_LEADER_CODE,
    last_seen: now,
  };

  const snap = await ref.get();
  if (!snap.exists) {
    payload.created_at = now;
    payload.is_banned = false;
    payload.access_level = 'visitor';
  }

  await ref.set(payload, { merge: true });
  return payload;
}

async function getLeaderByCode(leaderCode) {
  const code = cleanLeaderCode(leaderCode) || env.DEFAULT_LEADER_CODE;
  const ref = db.collection('leaders').doc(String(code));
  const snap = await ref.get();
  if (!snap.exists) {
    return {
      ref,
      data: {
        leader_code: code,
        sponsor_id: code,
        is_active: true,
        subscription_active: true,
        vip_group_id: '',
        admin_group_id: env.ADMIN_GROUP_ID || '',
      },
      exists: false,
    };
  }

  return { ref, data: snap.data(), exists: true };
}

async function getLeaderConfigByUserId(telegramId) {
  const { data: user } = await getUser(telegramId);
  const leaderCode = cleanLeaderCode(user?.leader_code) || env.DEFAULT_LEADER_CODE;
  const leader = await getLeaderByCode(leaderCode);

  const sponsorId = leader.data?.sponsor_id || leaderCode || env.DEFAULT_LEADER_CODE;
  return {
    user_id: String(telegramId),
    leader_code: leaderCode,
    sponsor_id: sponsorId,
    registration_link: leader.data?.registration_link || buildRegistrationLink(sponsorId),
    vip_link: leader.data?.vip_link || '',
    admin_group_id: leader.data?.admin_group_id || env.ADMIN_GROUP_ID || '',
    is_active: leader.data?.is_active !== false,
    subscription_active: leader.data?.subscription_active !== false,
  };
}

module.exports = {
  cleanLeaderCode,
  buildRegistrationLink,
  getUser,
  upsertUserFromStart,
  getLeaderByCode,
  getLeaderConfigByUserId,
};
