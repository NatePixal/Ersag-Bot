ERSAG FIX PACK

What this fixes
- silent bot routing
- env freeze in Gen2
- billing route going to leader handler
- mini app sponsor ID hardcoded in HTML
- API/catalog loading split from bot runtime

Firebase secrets / env values to set
- MASTER_BOT_TOKEN
- LEADER_BOT_TOKEN
- SALES_BOT_TOKEN
- BILLING_BOT_TOKEN
- GROQ_API_KEY
- ADMIN_TELEGRAM_ID
- WEBHOOK_SECRET

Recommended non-secret env values
- WEBAPP_URL=https://your-project.web.app
- DEFAULT_LEADER_CODE=5422685
- ADMIN_GROUP_ID=-100xxxxxxxxxx
- GOOGLE_SHEETS_ID=your_sheet_id
- GROQ_MODEL=llama-3.3-70b-versatile
- PUBLIC_REG_URL=https://www.ersagglobal.uz/account.asp?mod=myaccount&sub=edit&action=register&p=1&red=&sponsor=5422685

Webhook URLs after deploy
- /webhook/master
- /webhook/leader
- /webhook/sales
- /webhook/billing

Example Telegram setWebhook calls
- https://api.telegram.org/bot<MASTER_BOT_TOKEN>/setWebhook?url=https://<region>-<project>.cloudfunctions.net/botGateway/webhook/master
- https://api.telegram.org/bot<LEADER_BOT_TOKEN>/setWebhook?url=https://<region>-<project>.cloudfunctions.net/botGateway/webhook/leader
- https://api.telegram.org/bot<SALES_BOT_TOKEN>/setWebhook?url=https://<region>-<project>.cloudfunctions.net/botGateway/webhook/sales
- https://api.telegram.org/bot<BILLING_BOT_TOKEN>/setWebhook?url=https://<region>-<project>.cloudfunctions.net/botGateway/webhook/billing

Mini app change you still must do in index (7).html
1) Remove the hardcoded sponsor ID text:
   5422685
2) Include /public/miniapp-loader.js
3) On page load, call:
   ErsagMiniApp.applyLeaderConfig(userId)
4) Replace any static sponsor copy logic with currentLeaderConfig.sponsor_id

Security notes
- Keep Google Sheets only for catalog / doctor content / videos.
- Keep user status, paid status, bans, leader mappings, and audit logs in Firestore.
- Do not let the frontend decide access.
